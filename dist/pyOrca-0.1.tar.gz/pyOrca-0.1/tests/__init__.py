# -*- coding: utf-8 -*-
"""
Created on Tue Jun 11 17:45:35 2024

@author: DAlexander
"""

