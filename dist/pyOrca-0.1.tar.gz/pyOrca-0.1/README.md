# pyOrca

A Python package for communicating with the Orca motor using Modbus.

## Installation

```sh
pip install pyOrca